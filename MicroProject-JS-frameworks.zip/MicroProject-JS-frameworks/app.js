const express = require("express");
const app = express();
const port = 3000;
const cars = require("./data/cars.json");

app.use(express.static("public"));

app.get("/api/cars", (req, res) => {
  res.json(cars);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
